# Task 2

- [ x] a.
- [ x] b.
- [ x] c.
- [ x] d.
- [ x] e.
- [x ] f.
- [ x] g.
- [ x] h.
